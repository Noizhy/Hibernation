#!/system/bin/sh
MODDIR=${0%/*}
# # #  P o s t - f s - d a t a . s h  # # #
# Created By @KaizeSource a.k.a Kaize Team
# Published on Telegram on 14 - 2 - 2024

# Please Remember, always to give us a credit if you want to use our code.
# And also, if we do not found who made the script code that included in here, please let us know by dm-ing us so that we can correct it and give a credit to them.

# Disable GMS, Credit to @KaizeTeam
pm disable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
pm disable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver