SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE="
"

# Checking if busybox is installed, Credit to the person who made it.
GetBusyBox="none"
alias DSC="["
alias DDC="[["
sleep 1s
for i in /system/bin /system/xbin /sbin /su/xbin /data/adb/modules/busybox-ndk/system/xbin /data/adb/modules_update/busybox-ndk/system/xbin /data/adb/modules/busybox-ndk/system/bin /data/adb/modules_update/busybox-ndk/system/bin
do
    if [[ "$GetBusyBox" == "none" ]]; then
        if [[ -f $i/busybox ]]; then
            GetBusyBox=$i/busybox
        fi
    fi
done

if [[ "$GetBusyBox" == "none" ]];then
    GetBusyBox=""
    abort "ERROR: Please Flash Busybox First!"
else
    for ListCmds in $($GetBusyBox --list)
    do
        if [[ "$ListCmds" == "[" ]];then
            alias "DSC"="$GetBusyBox $ListCmds"
        elif [[ "$ListCmds" == "[[" ]];then
            alias "DDC"="$GetBusyBox $ListCmds"
        else
            alias "$ListCmds"="$GetBusyBox $ListCmds"
        fi
    done
fi

# Permission For install.sh
chmod 755 $MODPATH/install.sh

# Check if module author, Credit to @KaizeSource, DONT RENAME IT OR YOUR LIFE WILL BE CURSED FOREVER !
AUTHOR="@KaizeSource 🇮🇩"

if grep -q "$AUTHOR" module.prop; then
sleep 0.008
ui_print "🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩"
sleep 0.008
ui_print "               Hibernation   "
sleep 0.008
ui_print "         Realeased At : 19 - 2 - 2024"
sleep 0.008
ui_print "          Please Give us A FeedBack "
sleep 0.008
ui_print "🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩🇮🇩"
ui_print ""
sleep 2
else
    ui_print "Module author is not Original a.k.a you've been renaming it, Installation aborted."
    exit 1
fi

# Check if ID is original or not
ui_print ""
if grep -q "$ID" module.prop; then
    ui_print ""
    ui_print "Connected Android Device Information:"
    ui_print "====================================="
    sleep 3
    ui_print "Android version: $(getprop ro.build.version.release)"
    ui_print "Brand: $(getprop ro.product.system.manufacturer)"
    ui_print "Build number: $(getprop ro.build.display.id)"
    ui_print "CPU: $(getprop ro.hardware)"
    ui_print "Device: $(getprop ro.product.model)"
    ui_print "Kernel: $(uname -r)"
    ui_print "Locale: $(getprop ro.product.locale)"
    ui_print "Model: $(getprop ro.build.product)"
    ui_print "Nation/region: $(getprop ro.build.oplus_nv_id)"
    ui_print "Processor: $(getprop ro.product.board)"
    ui_print "RAM: $(free | grep Mem | awk '{print $2}')"
    ui_print "Baseline: $(getprop ro.build.version.incremental)"

    # Unzip files
    ui_print ""
    sleep 3
    ui_print "Flashing module..."
    unzip -o "$ZIPFILE" 'common/*' -d $MODPATH >&2
    unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" service.sh -d $MODPATH >&2

    # Set permissions
    ui_print ""
    sleep 3
    ui_print "Setting permissions..."
    set_permissions
    set_perm_recursive $MODPATH 0 0 0777 0755

    # Final message
    ui_print ""
    sleep 3
    ui_print "All done, now please reboot, but, please support us by joining our telegram channel please."
    sleep 3
    su -c "nohup am start -a android.intent.action.VIEW -d https://t.me/KaizeSource >/dev/null 2>&1 &"