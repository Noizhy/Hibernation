#!/system/bin/sh

# # #  S e r v i c e  .  s h # # #
# Created By @KaizeSource a.k.a Kaize Team
# Published on Telegram at 14 - 2 - 2024

rm -rf /data/media/0/Android/KaizeModules
mkdir /data/media/0/Android/KaizeModules

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
    chmod 644 "$1"  
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 644 "$1"  
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}

msg_on() {
    local msg="$1"
    local log_path="/data/media/0/Android/KaizeModules/Hibernate-Kaize.log"
    echo "Device Turned On | $msg" >> "$log_path"
    echo "" >> "$log_path"
}

msg_off() {
    local msg="$1"
    local log_path="/data/media/0/Android/KaizeModules/Hibernate-Kaize.log"
    echo "Device Turned Off | $msg" >> "$log_path"
    echo "" >> "$log_path"
}

# This Script is made by @Noizhy

# Apps list
APPS="com.facebook.katana com.whatsapp com.instagram.android com.twitter.android com.netflix.mediaclient com.spotify.music com.amazon.mShop.android.shopping com.ubercab com.google.android.apps.maps com.airbnb.android com.snapchat.android com.linkedin.android com.google.android.gm com.tinder com.paypal.android.p2pmobile com.shazam.android com.pinterest com.skype.raider com.dropbox.android com.evernote com.reddit.frontpage com.microsoft.office.outlook com.sonyliv com.google.android.youtube com.discord com.zoom.us com.tiktok com.microsoft.teams com.squareup.cash com.google.android.apps.docs com.king.candycrushsaga com.supercell.clashofclans com.supercell.clashroyale com.miniclip.eightballpool com.playrix.gardenscapes com.zynga.poker com.outfit7.mytalkingtomfriends com.moonactive.coinmaster com.king.candycrushsoda com.roblox.client com.playrix.homescapes com.kiloo.subwaysurf com.supercell.brawlstars com.playgendary.kickthebuddy com.supersolid.harry com.jamcity.cookiedunk com.igg.castleclash com.ninjakiwi.bloonstd6 com.ea.gp.fifamobile com.activision.callofduty.shooter com.king.candycrushjellysaga com.robtopx.geometryjump com.halfbrick.fruitninjafree com.jetstartgames.chess com.mojang.minecraftpe com.playdead.limbo.full com.yodo1.crossyroad com.ketchapp.basketball com.supercell.hayday com.gameinsight.gobandroid com.noodlecake.altosadventure com.playdigious.deadcells com.glukom.paket com.madfingergames.deadtrigger2 com.sgn.pandapop.gp com.etermax.preguntados.lite com.gameloft.android.ANMP.GloftM5HM com.bandainamcogames.dbzdokkanww com.giantssoftware.fs14 com.ea.game.pvz2_row com.ea.game.starwarscapital_row com.firsttouchgames.dls3 com.fingersoft.hcr2 com.madfingergames.unkilled com.miniclip.agar.io com.slightlymad.badpiggies com.gameloft.android.ANMP.GloftA8HM com.pixel.gun3d com.wargaming.worldoftanks.blitz com.netease.chiji com.dts.freefireth com.dts.freefiremax com.mobile.legends"

# Specify the CPUs to be manipulated
CPUS="2 3 4 5 6"

# Script to disable CPUs
disable_cpus() {
    msg_off "Disabling CPUs..."
    for CPU in $CPUS; do
        echo 0 > "/sys/devices/system/cpu/cpu${CPU}/online"
    done
}

# Script to enable CPUs
enable_cpus() {
    msg_on "Enabling CPUs..."
    for CPU in $CPUS; do
        echo 1 > "/sys/devices/system/cpu/cpu${CPU}/online"
    done
}

# Script to enable Hibernate (Replace 'com.package.name' with the appropriate package name)
hibernate_apps() {
    msg_off "Enabling Hibernate..."
        for APP in $APPS; do
        am set-inactive $APP true
    done
}

# Script to disable Hibernate
unhibernate_apps() {
    msg_on "Disabling Hibernate..."
        for APP in $APPS; do
        am set-inactive $APP false
    done
}

# Script to enable Power Save Mode
enable_power_save() {
    msg_off "Enabling Power Save Mode..."
    settings put global low_power 1
}

# Script to disable Power Save Mode
disable_power_save() {
    msg_on "Disabling Power Save Mode..."
    settings put global low_power 0
}

# Detect when the screen is turned off and on
screen_off() {
    disable_cpus
    hibernate_apps
    enable_power_save
    sleep 3
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Kaize Modulo' 'Tag' 'Device Status: off '"
}

screen_on() {
    unhibernate_apps
    disable_power_save
    enable_cpus
    sleep 3
    su -lp 2000 -c "cmd notification post -S bigtext -t 'Kaize Modulo' 'Tag' 'Device Status: on '"
}

while true; do
    if dumpsys window | grep mScreen | grep false; then
        screen_off
    elif dumpsys window | grep mScreen | grep true; then
        screen_on
    fi
    sleep 10
done

